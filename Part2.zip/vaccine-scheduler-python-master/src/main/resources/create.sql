CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Time date,
    Username varchar(255) REFERENCES Caregivers,
    Exist varchar(10),
    PRIMARY KEY (Time, Username)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);

CREATE TABLE Patients (
    Name varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Name)
);

CREATE TABLE Appointment (
    Appointment_id int,
    P_Name varchar(255) REFERENCES Patients(Name),
    Time date，
    C_Name varchar(255) REFERENCES Caregivers(Username),
    V_Name varchar(255) REFERENCES Vaccines(Name),
    PRIMARY KEY(Appointment_id)
);


